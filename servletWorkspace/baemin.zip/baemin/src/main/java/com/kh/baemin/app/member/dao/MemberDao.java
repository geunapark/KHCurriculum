package com.kh.baemin.app.member.dao;

public class MemberDao {

}
