package com.kh.app09;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class App09ApplicationTests {

	@Test
	void contextLoads() {
	}

}
