package com.kh.app99;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class App99ApplicationTests {

	@Test
	void contextLoads() {
	}

}
