package com.kh.app16;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class App16ApplicationTests {

	@Test
	void contextLoads() {
	}

}
