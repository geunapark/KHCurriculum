package com.kh.app06;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class App06Application {

	public static void main(String[] args) {
		SpringApplication.run(App06Application.class, args);
	}

}
