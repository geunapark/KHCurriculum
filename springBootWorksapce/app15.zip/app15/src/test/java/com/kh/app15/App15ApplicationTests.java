package com.kh.app15;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class App15ApplicationTests {

	@Test
	void contextLoads() {
	}

}
