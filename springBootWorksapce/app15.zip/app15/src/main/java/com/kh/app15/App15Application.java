package com.kh.app15;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class App15Application {

	public static void main(String[] args) {
		SpringApplication.run(App15Application.class, args);
	}

}
